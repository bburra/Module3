package com.cg.dto;

import java.time.LocalDate;

public class TransactionBean {
	private long transactionId;
	private String transDesc;
	private double transAmount;
	private LocalDate transDate;
	private String accountNumber;

	public TransactionBean() {
		
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransDesc() {
		return transDesc;
	}

	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}

	public double getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(double transAmount) {
		this.transAmount = transAmount;
	}

	public LocalDate getTransDate() {
		return transDate;
	}

	public void setTransDate(LocalDate transDate) {
		this.transDate = transDate;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	@Override
	public String toString() {
		return "TransactionBean [transactionId=" + transactionId
				+ ", transDesc=" + transDesc + ", transAmount=" + transAmount
				+ ", transDate=" + transDate + ", accountNumber="
				+ accountNumber + "]";
	}

	
}
