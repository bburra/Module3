package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.BankDAO;
import com.cg.dao.IBankDAO;
import com.cg.dto.AccountBean;
import com.cg.dto.TransactionBean;
import com.cg.exception.CustomerException;
/*
 * Implementing the IEBillService interface and all its methods
 */
public class BankService implements IBankService {
	IBankDAO bankDAO=null;
	public BankService() {
		super();
		bankDAO = new BankDAO();
	}
	@Override
	public int insertTransactionDetails(TransactionBean transBean)
			throws CustomerException {
		int status = bankDAO.insertTransactionDetails(transBean);
		if(status==0){
			throw new CustomerException("Cannot Insert the Transaction Details");
		}
		return status;
	}
	@Override
	public int isCustomerValid(String customerName) throws CustomerException {
		int count = bankDAO.isCustomerValid(customerName);
		if(count==0){
			throw new CustomerException("Customer Name Not Found Exception");
		}
		return count;
	}
	@Override
	public ArrayList<AccountBean> showAccountDetails(String customerName)
			throws CustomerException {
		ArrayList<AccountBean> accDetails = bankDAO.showAccountDetails(customerName);
		if(accDetails==null || accDetails.size()==0){
			throw new CustomerException("No Account Details Available for - "+customerName);
		}
		return accDetails;
	}


	
}
