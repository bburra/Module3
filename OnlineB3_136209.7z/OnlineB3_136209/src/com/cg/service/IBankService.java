package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.AccountBean;
import com.cg.dto.TransactionBean;
import com.cg.exception.CustomerException;
/*
 * TruckService Interface declaring all the functions to perform
 */
public interface IBankService {
	int insertTransactionDetails(TransactionBean transBean) throws CustomerException;
	public int isCustomerValid(String customerName) throws CustomerException;
	public ArrayList<AccountBean> showAccountDetails(String customerName) throws CustomerException;
}
