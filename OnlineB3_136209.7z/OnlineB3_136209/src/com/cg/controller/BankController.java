package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.AccountBean;
import com.cg.dto.TransactionBean;
import com.cg.exception.CustomerException;
import com.cg.service.BankService;
import com.cg.service.IBankService;


@WebServlet("/BankController")
public class BankController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	AccountBean accBean;
	IBankService bankService;
       
   
    public BankController() {
        super();
        bankService = new BankService();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	public static void main(String[] args)
	{
		System.out.println("in Main");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		accBean = new AccountBean();
		int action = Integer.parseInt(request.getParameter("action"));
		TransactionBean transBean = null;
		System.out.println("abcd");
		PrintWriter out =response.getWriter();
		out.println("cdef");
		
		
		switch(action){
		case 1:
			String accountNumber = request.getParameter("accNum");
			double transAmount = Double.parseDouble(request.getParameter("amount"));
			transBean = new TransactionBean();
			transBean.setTransAmount(transAmount);
			transBean.setAccountNumber(accountNumber);
				
				try {
					int status = bankService.insertTransactionDetails(transBean);
					if(status==1){
						request.setAttribute("accNum", accountNumber);
						request.setAttribute("transAmount", transAmount);
						RequestDispatcher rd = request.getRequestDispatcher("TransactionSuccess.jsp");
						rd.forward(request, response);
					}
					
				} catch (CustomerException e) {
					request.setAttribute("error", e.getMessage());
					RequestDispatcher rd = request.getRequestDispatcher("CustomerError.jsp");
					rd.forward(request, response);
				}
			
			break;
		case 2:
			
			String customerName = request.getParameter("custname");
			
			try {
				int status = bankService.isCustomerValid(customerName);
				if(status!=0){
					ArrayList<AccountBean> customerAccDetails = bankService.showAccountDetails(customerName);
					request.setAttribute("customerName", customerName);
					request.setAttribute("customerAccDetails", customerAccDetails);
					RequestDispatcher rd = request.getRequestDispatcher("AccountInfo.jsp");
					rd.forward(request, response);
				}
				
			} catch (CustomerException e) {
				request.setAttribute("error", e.getMessage());
				RequestDispatcher rd = request.getRequestDispatcher("CustomerError.jsp");
				rd.forward(request, response);
			}
			break;
	
		case 3: 
			break;
		}
		
	}
}
